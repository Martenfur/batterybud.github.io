After launch, turn on permanent showing of Battery Bud icon on taskbar
in Windows settings.
To achieve the sickest look, place Battery Bud icon next to default 
battery icon.

Before deleting Battery Bud, remove it from autostart via
Battery Bud context menu. 

Contact me: foxoftgames@gmail.com
My twitter: twitter.com/FoXoftGames

Don't forget to hug some foxes.












...and yes, there are 100 icons in res folder. :c
